The original i400x_analyzer_20181115.zip is packed into another password protected 7zip file.

Use password 'Four-0-Zero-4 forever!' (without the quotes) to extract the original zip.

This was done in order to hide the content from the automatic scanner programs, This way
it can be easier distributed, such as an e-mail attachment.

Note also, that unfortunately the latest antivirus systems may detect the original exe programs
as virus most probably due to their heuristic algorithms (although the package remained unchanged).
If you do not trust in the software, unpack and run the package in a network isolated environment,
which can be easily created as a virtual machine on your host PC.

You can get 7zip from https://www.7-zip.org/